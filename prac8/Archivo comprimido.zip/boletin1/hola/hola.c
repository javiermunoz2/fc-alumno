#include <stdio.h>

int main() {
    printf("Hola, mundo!\n");
}
